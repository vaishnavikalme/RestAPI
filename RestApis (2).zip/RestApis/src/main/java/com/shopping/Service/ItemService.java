package com.shopping.Service;

	import java.util.List;
import java.util.Optional;

import com.shopping.Entity.Item;

	public interface ItemService {

	    // Add a new item
	    Item addItem(Item item);

	    // Get item by ID
	    Optional<Item> getItemById(int id);

	    // Get all items
	    List<Item> getAllItems();
	}


